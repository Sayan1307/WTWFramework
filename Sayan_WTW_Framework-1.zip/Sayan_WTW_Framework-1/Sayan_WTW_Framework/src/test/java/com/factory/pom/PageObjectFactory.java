package com.factory.pom;

import com.pom.pages.CartPage;
import com.pom.pages.*;
import org.openqa.selenium.WebDriver;

public class PageObjectFactory
{
    private static CartPage cartPage;
    private static CheckoutPage checkoutPage;
    private static LoginPage loginPage;
    private static CheckoutCompletePage checkoutCompletePage;
    private static CheckoutOverviewPage checkoutOverviewPage;
    private static HomePage homePage;
    private static ProductPage productPage;

    public static CheckoutPage getCheckoutPage(WebDriver driver)
    {
        return checkoutPage == null ?  new CheckoutPage(driver) :  checkoutPage;
    }

    public static CartPage getCartPage(WebDriver driver)
    {
        return cartPage == null ?  new CartPage(driver) :  cartPage;
    }

    public static CheckoutCompletePage getCheckoutCompletePage(WebDriver driver)
    {
        return checkoutCompletePage == null ?  new CheckoutCompletePage(driver) :  checkoutCompletePage;
    }

    public static CheckoutOverviewPage getCheckoutOverviewPage(WebDriver driver)
    {
        return checkoutOverviewPage == null ?  new CheckoutOverviewPage(driver) :  checkoutOverviewPage;
    }

    public static HomePage getHomePage(WebDriver driver)
    {
        return homePage == null ?  new HomePage(driver) :  homePage;
    }

    public static LoginPage getLoginPage(WebDriver driver)
    {
        return loginPage == null ?  new LoginPage(driver) :  loginPage;
    }

    public static ProductPage getProductPage(WebDriver driver)
    {
        return productPage == null ?  new ProductPage(driver) :  productPage;
    }
}
