package com.stepDef;

import com.contexts.TestContext;
import com.factory.pom.PageObjectFactory;
import com.pom.pages.*;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HomePageStepDef
{
    private final HomePage homePage;
    private final LoginPage loginPage;
    private final ProductPage productPage;
    private final CartPage cartPage;
    private final CheckoutPage checkoutPage;
    private final CheckoutOverviewPage checkoutOverviewPage;
    private final CheckoutCompletePage checkoutCompletePage;

    public HomePageStepDef(TestContext context){

        homePage = PageObjectFactory.getHomePage(context.driver);
        loginPage = PageObjectFactory.getLoginPage(context.driver);
        productPage = PageObjectFactory.getProductPage(context.driver);
        cartPage = PageObjectFactory.getCartPage(context.driver);
        checkoutPage=PageObjectFactory.getCheckoutPage(context.driver);
        checkoutOverviewPage=PageObjectFactory.getCheckoutOverviewPage(context.driver);
        checkoutCompletePage=PageObjectFactory.getCheckoutCompletePage(context.driver);
    }

    @Given("I login to the application")
    public void i_login_to_the_application() {
        homePage.navigate("");
    }
    @Given("I enter Username {string}")
    public void i_enter_username(String uName) {
        homePage.enterUserName(uName);
    }
    @Given("I enter Password {string}")
    public void i_enter_password(String pwd) {
        homePage.enterPassword(pwd);
    }
    @When("I Click Login")
    public void i_click_login() {
        homePage.clickLogin();
    }
    @Then("I validate the login error")
    public void i_validate_the_login_error() {
        homePage.validateInvalidLogin();
    }

    @When("I Click Menu Icon")
    public void i_click_menu_icon() {
        loginPage.clickMenu();
    }
    @When("I Click Logout")
    public void i_click_logout() {
        loginPage.clickLogout();
    }
    @Then("I Validate Home Page")
    public void i_validate_home_page() {
        homePage.validateInvalidLogin();
    }
    @When("I select High To Low Selection")
    public void i_select_high_to_low_selection() {
        productPage.selectLowToHigh();
    }
    @When("I Validate Ascending Order Price")
    public void i_validate_ascending_order_price() {
        productPage.validateAccendingPrice();
    }
    @When("I click Add To Cart for {string}")
    public void i_click_add_to_cart_for(String var) {
        productPage.validateAddToCart(var);
    }
    @Then("I validate Remove button enabled for {string}")
    public void i_validate_remove_button_enabled_for(String var) {
        productPage.validateRemove(var);
    }
    @Then("I Capture Price for {string}")
    public void i_capture_price_for(String var) {
        productPage.capturePrice(var);
    }
    @Then("I Check cart Value is {string}")
    public void i_check_cart_value_is(String var) {
        productPage.checkCartValue(var);
    }
    @Then("I Click Cart")
    public void i_click_cart() {
        productPage.clickCart();
    }
    @Then("I Validate Cart Price of {string} is {string}")
    public void i_validate_cart_price_of_is(String var1, String var2) {
        cartPage.capturePrice(var1,var2);
    }
    @Then("I Click Remove for {string}")
    public void i_click_remove_for(String string) {
        productPage.clickRemoveButton();
    }
    @Then("I Click Checkout")
    public void i_click_checkout() {
        cartPage.checkout();
    }
    @When("I Enter First Name {string} in Checkout Page")
    public void i_enter_first_name_in_checkout_page(String var) {
        checkoutPage.enterFirstName(var);
    }
    @When("I Enter Last Name {string} in Checkout Page")
    public void i_enter_last_name_in_checkout_page(String var) {
        checkoutPage.enterLastName(var);
    }
    @When("I Enter Postal Code {string} in Checkout Page")
    public void i_enter_postal_code_in_checkout_page(String var) {
        checkoutPage.enterPostalCode(var);
    }

    @Then("I Click Continue")
    public void i_click_continue() {
        checkoutPage.clickContinue();
    }
    @Then("I Validate Item Total is {string}")
    public void i_validate_item_total_is(String var) {
        checkoutOverviewPage.viewItemTotal(var);
    }
    @Then("I Click Finish")
    public void i_click_finish() {
        checkoutOverviewPage.clickFinish();
    }
    @Then("I Validate Thank You Message")
    public void i_validate_thank_you_message() {
        checkoutCompletePage.checkThankYou();
    }

    @When("I Click Reset App State")
    public void i_click_reset_app_state() {
        loginPage.clickResetApp();
    }
    @When("I refresh the browser")
    public void i_refresh_the_browser() {
        loginPage.performRefresh();
    }
    @When("I Validate Remove Button is not visible")
    public void i_validate_remove_button_is_not_visible() {
        productPage.removeButtonAbsent();
    }
    @When("I Validate Add To Cart is enabled for {string}")
    public void i_validate_add_to_cart_is_enabled_for(String var) {
        productPage.validateAddToCart(var);
    }
    @Then("I Validate Cart Value is Absent")
    public void i_validate_cart_value_is_absent() {
        productPage.checkCartValueAbsent();
    }
    @When("I Click All Items")
    public void i_click_all_items() {
        loginPage.clickAllItems();
    }
    @When("I Click Twitter")
    public void i_click_twitter() {
        loginPage.clickTwitter();
    }
    @When("I Click Facebook")
    public void i_click_facebook() {
        loginPage.clickFacebook();
    }
    @When("I Click LinkedIn")
    public void i_click_linked_in() {
        loginPage.clickLinkedIn();
    }
    @When("I Close Facebook")
    public void i_close_facebook() {
        loginPage.closeNewWindow("facebook");
    }
    @When("I Close Twitter")
    public void i_close_twitter() {
        loginPage.closeNewWindow("x.com");
    }
    @When("I Navigate to Home Tab")
    public void i_navigate_to_home_tab() {

    }
    @When("I Close LinkedIn")
    public void i_close_linked_in() {
        loginPage.closeNewWindow("linkedIn");
    }
}
