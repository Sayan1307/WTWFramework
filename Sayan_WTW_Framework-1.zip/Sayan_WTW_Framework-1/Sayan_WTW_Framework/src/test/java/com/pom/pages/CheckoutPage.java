package com.pom.pages;

import com.pojo.objects.BillingDetails;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class CheckoutPage extends BasePage
{
    public CheckoutPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(id = "first-name") private WebElement firstName;
    @FindBy(id = "last-name") private WebElement lastName;
    @FindBy(id = "postal-code") private WebElement postalCode;
    @FindBy(id = "continue") private WebElement continueButton;

    private String pageNav ="/checkout";

    public void navigate()
    {
        super.navigate(pageNav);
    }

    public void enterFirstName(String firstname){
        wait.until(ExpectedConditions.visibilityOf(firstName)).sendKeys(firstname);
    }

    public void enterLastName(String lastname){
        wait.until(ExpectedConditions.visibilityOf(lastName)).sendKeys(lastname);
    }

    public void enterPostalCode(String postalCd){
	wait.until(ExpectedConditions.visibilityOf(postalCode)).sendKeys(postalCd);
    }

    public void clickContinue(){
        wait.until(ExpectedConditions.elementToBeClickable(continueButton)).click();
    }
}
