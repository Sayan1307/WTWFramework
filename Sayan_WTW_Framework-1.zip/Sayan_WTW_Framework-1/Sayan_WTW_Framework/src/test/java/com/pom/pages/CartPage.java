package com.pom.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

public class CartPage extends BasePage
{
    @FindBy(id = "checkout") private WebElement checkout;

    public CartPage(WebDriver driver) {
        super(driver);
    }

    private String pageNav ="/?wc-ajax=add_to_cart";
    public void navigate(String pageNav)
    {
        super.navigate(pageNav);
    }

    public void checkout(){
        wait.until(ExpectedConditions.elementToBeClickable(checkout)).click();
    }

    public void capturePrice(String entity, String price){
	String path="//div[text()='"+entity+"']/../../..//div[@class='inventory_item_price]";
	WebElement addToCart= driver.findElement(By.xpath(path));
        String pricenew=addToCart.getText();
	Assert.assertTrue(price.equals(pricenew));
    }

    public void clickRemove(String entity){
	String path="//div[text()='"+entity+"']/../../..//button[text()='Remove']";
        WebElement addToCart= driver.findElement(By.xpath(path));
        wait.until(ExpectedConditions.elementToBeClickable(addToCart)).click();
    }

}
