package com.pom.pages;

import com.pojo.objects.BillingDetails;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

public class CheckoutOverviewPage extends BasePage
{
    public CheckoutOverviewPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//button[text()='Finish']") private WebElement finishButton;
    @FindBy(xpath = "//div[@class='summary_subtotal_label']") private WebElement itemTotal;


    private String pageNav ="/checkout";

    public void navigate()
    {
        super.navigate(pageNav);
    }

    public void clickFinish(){
        wait.until(ExpectedConditions.elementToBeClickable(finishButton)).click();
    }


    public void viewItemTotal(String value){
       String itemValue=itemTotal.getText();
	String actItemValue=itemValue.substring(11);
	Assert.assertTrue(value.equals(actItemValue));
    }
}
