package com.pom.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class HomePage extends BasePage
{
    public HomePage(WebDriver driver) {
        super(driver);
    }

    @FindBy(id = "user-name") private WebElement userName;
    @FindBy(id = "password") private WebElement password;
    @FindBy(id = "login-button") private WebElement loginButton;
    @FindBy(xpath = "//button[@class='error-button']/..") private WebElement errorMessage;
    @FindBy(xpath = "//div[text()='Swag Labs']") private WebElement checkHomeScreen;

    private String pageNav ="";
    public void navigate(String pageNav)
    {
        super.navigate(pageNav);
    }


    public void enterUserName(String username){
        wait.until(ExpectedConditions.visibilityOf(userName)).sendKeys(username);
	
    }

    public void enterPassword(String pwd){
	wait.until(ExpectedConditions.visibilityOf(password)).sendKeys(pwd);
    }

    public void clickLogin(){
        wait.until(ExpectedConditions.elementToBeClickable(loginButton)).click();
    }

    public void validateInvalidLogin(){
        wait.until(ExpectedConditions.visibilityOf(errorMessage));
    }

    public void checkHomePage(){
        wait.until(ExpectedConditions.visibilityOf(checkHomeScreen));
    }
}
