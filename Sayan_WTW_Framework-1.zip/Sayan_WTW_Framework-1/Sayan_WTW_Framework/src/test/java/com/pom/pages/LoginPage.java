package com.pom.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LoginPage extends BasePage
{
    WebDriver driver;
    public LoginPage(WebDriver driver) {
        super(driver);
        this.driver=driver;
    }

    @FindBy(id = "react-burger-menu-btn") private WebElement menu;
    @FindBy(xpath = "//a[text()='Logout']") private WebElement logoutButton;
    @FindBy(xpath = "//a[text()='Reset App State']") private WebElement resetAppButton;
    @FindBy(xpath = "//a[text()='All Items']") private WebElement allItems;
    @FindBy(xpath = "//a[text()='Twitter']") private WebElement twitter;
    @FindBy(xpath = "//a[text()='Facebook']") private WebElement facebook;
    @FindBy(xpath = "//a[text()='LinkedIn']") private WebElement linkedin;

    private String pageNav ="/?wc-ajax=add_to_cart";
    public void navigate(String pageNav)
    {
        super.navigate(pageNav);
    }


    public void clickMenu(){
        wait.until(ExpectedConditions.elementToBeClickable(menu)).click();	
    }

    public void clickLogout(){
        wait.until(ExpectedConditions.elementToBeClickable(logoutButton)).click();
    }

    public void clickResetApp(){
        wait.until(ExpectedConditions.elementToBeClickable(resetAppButton)).click();
    }

    public void clickAllItems(){
        wait.until(ExpectedConditions.elementToBeClickable(allItems)).click();
    }

    public void clickTwitter(){
        wait.until(ExpectedConditions.elementToBeClickable(twitter)).click();
    }

    public void clickFacebook(){
        wait.until(ExpectedConditions.elementToBeClickable(facebook)).click();
    }

    public void clickLinkedIn(){
        wait.until(ExpectedConditions.elementToBeClickable(linkedin)).click();
    }

    public void performRefresh(){
        driver.navigate().refresh();
    }

    public void closeNewWindow(String url)
    {
       String base = driver.getWindowHandle();
       for(String window: driver.getWindowHandles())
       {
           if(!window.equals(base))
           {
               driver.switchTo().window(window);
               if(driver.getCurrentUrl().contains(url)){
                   break;
               }
           }
       }
       if(!driver.getWindowHandle().equals(base)){driver.close();}
       driver.switchTo().window(base);
    }

}
