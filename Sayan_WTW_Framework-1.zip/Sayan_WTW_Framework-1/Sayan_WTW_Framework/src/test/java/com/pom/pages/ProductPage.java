package com.pom.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.util.List;

public class ProductPage extends BasePage
{
    public ProductPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(id = "shopping_cart_container") private WebElement cart;
    @FindBy(xpath = "//div[@id='shopping_cart_container']/a/span") private WebElement cartValue;
    @FindBy(xpath = "//button[text()='Remove']") private WebElement removeButton;
    @FindBy(xpath = "//select") private WebElement filter;

    private String pageNav ="/?wc-ajax=add_to_cart";
    public void navigate(String pageNav)
    {
        super.navigate(pageNav);
    }


    public void clickCart(){
        wait.until(ExpectedConditions.elementToBeClickable(cart)).click();
    }

    public void checkCartValueAbsent(){
        wait.until(ExpectedConditions.invisibilityOf(cartValue));
    }

    public void checkCartValue(String num){
        String val=cartValue.getText();
	Assert.assertTrue(val.equals(num));
    }

    public void removeButtonAbsent(){
        wait.until(ExpectedConditions.invisibilityOf(removeButton));
    }

    public void clickRemoveButton(){
        wait.until(ExpectedConditions.elementToBeClickable(removeButton)).click();
    }

    public void clickAddToCart(String entity){
	String path="//div[text()='"+entity+"']/../../..//button[text()='Add to cart']";
	WebElement addToCart= driver.findElement(By.xpath(path));
        wait.until(ExpectedConditions.elementToBeClickable(addToCart)).click();
    }

    public void validateAddToCart(String entity){
	String path="//div[text()='"+entity+"']/../../..//button[text()='Add to cart']";
	WebElement addToCart= driver.findElement(By.xpath(path));
        wait.until(ExpectedConditions.elementToBeClickable(addToCart));
    }

    public void validateRemove(String entity){
	String path="//div[text()='"+entity+"']/../../..//button[text()='Remove']";
        WebElement addToCart= driver.findElement(By.xpath(path));
        wait.until(ExpectedConditions.elementToBeClickable(addToCart));
    }


    public void capturePrice(String entity){
	String path="//div[text()='"+entity+"']/../../..//div[@class='inventory_item_price]";
        WebElement addToCart= driver.findElement(By.xpath(path));
        String price=addToCart.getText();
    }

    public void validateNotAddToCart(String entity){
	String path="//div[text()='"+entity+"']/../../..//button[text()='Add to cart']";
        WebElement addToCart= driver.findElement(By.xpath(path));
        wait.until(ExpectedConditions.invisibilityOf(addToCart));
    }

    public void selectLowToHigh(){
        new Select(filter).selectByIndex(3);
    }

    public void validateAccendingPrice(){
       List<WebElement> elementList= driver.findElements(By.xpath("//div[@class='inventory_item_price']"));
	String val0= elementList.get(0).getText();
	String actVal0=val0.substring(1);
	for(int i=0;i<elementList.size();i++)
	{
	if(i>0)
		{
		String val= elementList.get(i).getText();
		String actVal=val.substring(1);
		String valOld= elementList.get(i-1).getText();
		String actValOld=val.substring(1);
		Assert.assertTrue((Integer.parseInt(actVal)>Integer.parseInt(actValOld)));
		}
	}
    }




}
