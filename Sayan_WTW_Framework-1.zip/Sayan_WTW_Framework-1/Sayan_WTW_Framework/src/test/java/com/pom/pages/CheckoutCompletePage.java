package com.pom.pages;

import com.pojo.objects.BillingDetails;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

public class CheckoutCompletePage extends BasePage
{
    public CheckoutCompletePage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "h2") private WebElement thankYou;

    private String pageNav ="/checkout";

    public void navigate()
    {
        super.navigate(pageNav);
    }

    public void checkThankYou(){
        wait.until(ExpectedConditions.elementToBeClickable(thankYou));
	String message=thankYou.getText();
	Assert.assertTrue(message.contains("Thank you"));
    }
}
