package com.pojo.objects;

public class Cookie {
}
