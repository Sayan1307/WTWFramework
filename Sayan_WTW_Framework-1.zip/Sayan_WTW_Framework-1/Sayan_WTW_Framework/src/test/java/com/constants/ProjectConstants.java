package com.constants;

public class ProjectConstants
{
    public static final String DEFAULTBROWSER = "chrome";
    public static final int DEFAULTTIMEOUT = 15;
}
