package com.constants;

public enum Environments
{
    QA,
    UAT
    //,STAGE,
    //PROD
}
